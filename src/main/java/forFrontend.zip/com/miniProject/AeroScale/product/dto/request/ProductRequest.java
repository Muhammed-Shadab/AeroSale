package com.miniProject.AeroScale.product.dto.request;

import com.miniProject.AeroScale.product.entity.Product.ProductStatus;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;


public record ProductRequest(

        @NotBlank(message = "Product name cannot be blank")
        @Size(max = 100, message = "Product name must not exceed 100 characters")
        String name,

        @Size(max = 5000, message = "Description must not exceed 5000 characters")
        String description,

        @NotNull(message = "Price is required")
        @DecimalMin(value = "0.01", message = "Price must be strictly greater than 0")
        BigDecimal price,


        @NotNull(message = "Product status is required")
        ProductStatus status
) {}

